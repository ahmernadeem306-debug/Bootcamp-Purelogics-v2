
 
import os
import pickle
from typing import Dict, List, Optional
 
import numpy as np
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, ConfigDict
from sklearn.datasets import load_iris
 
MODEL_PATH = os.path.join(os.path.dirname(__file__), "rf_model.pkl")
 
# Feature names are needed for the feature_importance response field
feature_names = load_iris().feature_names
 
 
def load_model():
    """Load the trained model from disk."""
    if not os.path.exists(MODEL_PATH):
        raise FileNotFoundError(
            "rf_model.pkl not found. Run 'python train_model.py' first."
        )
    with open(MODEL_PATH, "rb") as f:
        model = pickle.load(f)
    return model
 
 
# ---------------------------------------------------------------------
# Pydantic models (request / response schemas -> shown in Swagger UI)
# ---------------------------------------------------------------------
class IrisFeatures(BaseModel):
    features: List[float]
 
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "features": [5.1, 3.5, 1.4, 0.2]
            }
        }
    )
 
 
class PredictionResponse(BaseModel):
    prediction: List[int]
    probability: List[List[float]]
    feature_importance: Optional[Dict[str, float]] = None
 
 
# ---------------------------------------------------------------------
# App + model
# ---------------------------------------------------------------------
app = FastAPI(
    title="Iris Classifier API",
    description="API for classifying iris flowers using a RandomForest model",
    version="1.0.0",
)
 
model = load_model()
 
 
@app.get("/health")
async def health_check():
    return {"status": "healthy"}
 
 
@app.post("/predict", response_model=PredictionResponse)
async def predict_iris(iris_data: IrisFeatures):
    try:
        # Convert input features to numpy array
        features = np.array(iris_data.features).reshape(1, -1)
 
        # Make predictions
        prediction = model.predict(features).tolist()
        prediction_proba = model.predict_proba(features).tolist()
 
        # Get feature importance
        feature_importance = {}
        if hasattr(model, "feature_importances_"):
            for i, importance in enumerate(model.feature_importances_):
                feature_name = (
                    feature_names[i] if i < len(feature_names) else f"feature_{i}"
                )
                feature_importance[feature_name] = float(importance)
 
        return {
            "prediction": prediction,
            "probability": prediction_proba,
            "feature_importance": feature_importance,
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
 
 
if __name__ == "__main__":
    import uvicorn
 
    uvicorn.run("fastapi:app", host="0.0.0.0", port=8000, reload=True)