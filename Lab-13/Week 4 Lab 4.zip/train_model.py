from sklearn.datasets import load_iris
from sklearn.ensemble import RandomForestClassifier
import pickle

print("Training model...")

# Load Iris data
iris = load_iris()
X, y = iris.data, iris.target

# Train RandomForest
model = RandomForestClassifier(n_estimators=100)
model.fit(X, y)

# Save as pickle
with open("rf_model.pkl", "wb") as f:
    pickle.dump(model, f)

print("Done! rf_model.pkl created")