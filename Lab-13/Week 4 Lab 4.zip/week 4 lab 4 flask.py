
 
import os
import pickle
 
import numpy as np
from flask import Flask, request, jsonify
 
MODEL_PATH = os.path.join(os.path.dirname(__file__), "rf_model.pkl")
 
app = Flask(__name__)
 
 
def load_model():
    """Load the trained model from disk."""
    if not os.path.exists(MODEL_PATH):
        raise FileNotFoundError(
            "rf_model.pkl not found. Run 'python train_model.py' first."
        )
    with open(MODEL_PATH, "rb") as f:
        model = pickle.load(f)
    return model
 
 
# Load model once at startup (instead of on every request)
model = load_model()
 
 
@app.route("/", methods=["GET"])
def home():
    return jsonify({
        "message": "Iris Classifier API (Flask)",
        "endpoints": {
            "/predict": "POST -> {'features': [sepal_length, sepal_width, petal_length, petal_width]}",
            "/health": "GET -> health check"
        }
    })
 
 
@app.route("/health", methods=["GET"])
def health_check():
    return jsonify({"status": "healthy"})
 
 
@app.route("/predict", methods=["POST"])
def predict():
    # Get data from POST request
    data = request.get_json(silent=True)
 
    # Check if data is in correct format
    if not data or "features" not in data:
        return jsonify({"error": "No valid features provided"}), 400
 
    # Convert data to numpy array for prediction
    try:
        features = np.array(data["features"]).reshape(1, -1)
        prediction = model.predict(features).tolist()
        prediction_proba = model.predict_proba(features).tolist()
 
        return jsonify({
            "prediction": prediction,
            "probability": prediction_proba
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500
 
 
if __name__ == "__main__":
    # debug=True auto-reloads on code changes (dev only)
    app.run(debug=True, port=5000)