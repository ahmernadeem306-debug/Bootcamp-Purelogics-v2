
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional
 
from fastapi import FastAPI, Request, HTTPException, Depends
from pydantic import BaseModel
from sklearn.ensemble import RandomForestClassifier
from sklearn.datasets import load_iris
 

iris = load_iris()
X, y = iris.data, iris.target
iris_model = RandomForestClassifier(n_estimators=100, random_state=42)
iris_model.fit(X, y)
feature_names = iris.feature_names
 
 
class IrisFeatures(BaseModel):
    features: List[float]
 
    class Config:
        schema_extra = {
            "example": {
                "features": [5.1, 3.5, 1.4, 0.2]
            }
        }
 
 

class RateLimiter:
    def __init__(self, requests_limit: int = 5, window_seconds: int = 60):
        self.requests_limit = requests_limit
        self.window_seconds = window_seconds
        # client_id -> list of request timestamps
        self.requests: Dict[str, List[float]] = {}
 
    def _prune_old(self, client_id: str) -> None:
        """Remove timestamps that fall outside the current window."""
        cutoff = time.time() - self.window_seconds
        self.requests[client_id] = [
            ts for ts in self.requests.get(client_id, []) if ts > cutoff
        ]
 
    def is_rate_limited(self, client_id: str) -> bool:
        self._prune_old(client_id)
        return len(self.requests.get(client_id, [])) >= self.requests_limit
 
    def add_request(self, client_id: str) -> None:
        self._prune_old(client_id)
        self.requests.setdefault(client_id, []).append(time.time())
 
 
app = FastAPI(title="Iris Model API with Rate Limiting")
rate_limiter = RateLimiter(requests_limit=5, window_seconds=60)
 
 
async def check_rate_limit(request: Request):
    client_id = request.client.host if request.client else "unknown"
 
    if rate_limiter.is_rate_limited(client_id):
        raise HTTPException(
            status_code=429,
            detail="Rate limit exceeded. Max 5 requests per 60 seconds."
        )
 
    rate_limiter.add_request(client_id)
 
 
# ---------------------------------------------------------------------------
# PART 2: Performance Tracking
# ---------------------------------------------------------------------------
performance_metrics = {
    "total_requests": 0,
    "successful_predictions": 0,
    "failed_predictions": 0,
    "avg_response_time": 0.0,
    "prediction_distribution": {0: 0, 1: 0, 2: 0},
    "last_updated": None,
}
 
prediction_logs: List[dict] = []
 
 
async def update_metrics(features, prediction, response_time, success: bool = True):
    performance_metrics["total_requests"] += 1
 
    if success:
        performance_metrics["successful_predictions"] += 1
        pred_class = prediction[0]
        performance_metrics["prediction_distribution"][pred_class] += 1
    else:
        performance_metrics["failed_predictions"] += 1
 
    # running average of response time
    n = performance_metrics["total_requests"]
    current_avg = performance_metrics["avg_response_time"]
    performance_metrics["avg_response_time"] = (
        (current_avg * (n - 1) + response_time) / n
    )
 
    performance_metrics["last_updated"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
 
    prediction_logs.append({
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "features": features,
        "prediction": prediction,
        "response_time_sec": round(response_time, 4),
        "success": success,
    })
 
    if len(prediction_logs) > 100:
        prediction_logs.pop(0)
 
 

@app.post("/predict")
async def predict(
    iris_data: IrisFeatures,
    request: Request,
    rate_limit: None = Depends(check_rate_limit)
):
    start_time = time.time()
 
    try:
        features = [iris_data.features]
        prediction = iris_model.predict(features).tolist()
        prediction_proba = iris_model.predict_proba(features).tolist()
 
        response_time = time.time() - start_time
        await update_metrics(iris_data.features, prediction, response_time, success=True)
 
        return {
            "prediction": prediction,
            "probability": prediction_proba,
            "response_time_sec": round(response_time, 4)
        }
 
    except Exception as e:
        response_time = time.time() - start_time
        await update_metrics(iris_data.features, None, response_time, success=False)
        raise HTTPException(status_code=500, detail=str(e))
 

@app.get("/dashboard")
async def dashboard():
    return {
        "metrics": performance_metrics,
        "recent_logs": prediction_logs[-10:]
    }
 
 
@app.get("/health")
async def health_check():
    return {"status": "healthy"}
 
 
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)